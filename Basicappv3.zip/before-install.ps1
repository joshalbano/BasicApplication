$date = (get-date).ToString("yyyyddmm")
$zip = ".zip"
$backup = "Backup/"
$datezip = $date+$zip
$backupzip = $backup+$zip
$destination = 'C:\Users\Administrator\Desktop\Backup_zip_to_s3\'

#Compress-Archive -Path "C:\inetpub\wwwroot\BasicApp\*" -DestinationPath $destination\${datezip}
Move-Item -Path "C:\inetpub\wwwroot\basicapp\*" -Destination "C:\Users\wphdevops\Desktop\temporary\" 


#CMDLET Installation module
    #Install-Module -Name AWS.Tools.Installer
    #Install-AWSToolsModule AWS.Tools.EC2,AWS.Tools.S3 -CleanUp

#Write-S3Object -BucketName basicappbucket -Key $backupzip -File $destination\${datezip}


