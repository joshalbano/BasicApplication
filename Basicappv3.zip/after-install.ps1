Move-Item -Path "C:\Users\wphdevops\Desktop\temporary\*" -Destination "C:\inetpub\wwwroot\basicapp\" 
